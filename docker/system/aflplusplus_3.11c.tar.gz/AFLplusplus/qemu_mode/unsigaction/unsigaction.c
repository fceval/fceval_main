int sigaction(int signum, void *act, void *oldact) {
  return 0;
}
