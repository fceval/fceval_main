#include <src/mutator.h>
#include "test.pb.h"

class MyMutator : public protobuf_mutator::Mutator {
};
