/*
  Copyright 2013 Google LLC All rights reserved.

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at:

    http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
*/

/*
   american fuzzy lop - vaguely configurable bits
   ----------------------------------------------

   Written and maintained by Michal Zalewski <lcamtuf@google.com>
*/

#ifndef _AFL_STATSD_H
#define _AFL_STATSD_H

#include "types.h"
 
 #include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>

//zhaoxy add for afl statsd start
/* StatsD config
   Config can be adjusted via AFL_STATSD_HOST and AFL_STATSD_PORT environment
   variable.
*/
#define STATSD_UPDATE_SEC 1
#define STATSD_DEFAULT_PORT 9125
#define STATSD_DEFAULT_HOST "172.24.0.3"

/* StatsD */

void statsd_setup_format();
int  statsd_socket_init();
int  statsd_send_metric();
int  statsd_format_metric(char *buff, size_t bufflen);


//zhaoxy add for afl statsd end


#endif /* ! _AFL_STATSD_H*/
